<?php

namespace App\Filament\Resources\B2BAccounts\Pages;

use App\Filament\Resources\B2BAccounts\B2BAccountResource;
use Filament\Resources\Pages\CreateRecord;

class CreateB2BAccount extends CreateRecord
{
    protected static string $resource = B2BAccountResource::class;
}
